# Serenity Spa — Partner Portal

React 18 + TypeScript + Vite + Tailwind CSS partner portal for **RARE / Serenity Spa**, styled to the RARE Brand Bible (Dusty Rose & Champagne Gold edition).

## Stack

| Tool | Version |
|------|---------|
| React | 18 |
| TypeScript | 5 |
| Vite | 5 |
| Tailwind CSS | 3 |
| React Router | 6 |
| Context API | (built-in) |
| Vitest | 2 |
| Testing Library | 16 |

## Project structure

```
src/
├── components/
│   ├── ui/          # Reusable RARE-branded components
│   ├── layout/      # Sidebar, Topbar, Toast
│   ├── panels/      # One file per nav section (11 panels)
│   └── modals/      # NewBooking, CustomerDetail, BookingDetail
├── context/
│   └── AppContext.tsx  # Global state via useReducer + Context API
├── data/
│   └── seed.ts         # Static seed data + nav items
├── types/
│   └── index.ts        # All TypeScript interfaces
├── utils/
│   └── index.ts        # Helpers: fmtINR, initials, colour maps
└── test/
    ├── setup.ts
    ├── utils.test.ts
    └── context.test.tsx
```

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## Commands

```bash
npm run dev          # Start dev server
npm run build        # TypeScript check + Vite build
npm run preview      # Preview production build
npm test             # Run Vitest in watch mode
npm run test:ui      # Vitest UI
npm run test:coverage  # Coverage report
```

## RARE Brand Tokens

Defined in `tailwind.config.js` and `src/index.css`:

| Token | Hex | Usage |
|-------|-----|-------|
| `cream`  | `#FAF4EE` | Page backgrounds |
| `linen`  | `#F2DDD5` | Card alternates, section fills |
| `rose`   | `#C9897A` | Primary accent, CTA borders |
| `gold`   | `#D4AF7A` | Eyebrows, dividers, prices |
| `terra`  | `#A4594A` | Hover states, financial figures |
| `dark`   | `#2E1A1A` | Headings, sidebar, primary buttons |
| `mauve`  | `#7A4A4A` | Body copy |
| `muted`  | `#B09080` | Captions, secondary labels |

## Fonts

- **Playfair Display** — headings, stat values, logo
- **Cormorant Garamond** — times, amounts, editorial accents
- **Jost 300** — body, labels, buttons (ALL CAPS 10px)
