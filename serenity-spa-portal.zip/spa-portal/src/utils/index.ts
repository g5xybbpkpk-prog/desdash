import type { BookingStatus, PaymentStatus } from '../types';

export const tNow = (): string =>
  new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });

export const fmtINR = (n: number): string => '₹' + n.toLocaleString('en-IN');

export const initials = (name: string): string =>
  name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

export const avColors = ['#C9897A','#A4594A','#7A4A4A','#B09080'] as const;
export const avColor = (i: number): string => avColors[i % avColors.length];

export const ST_COLORS: Record<BookingStatus, [string, string, string]> = {
  confirmed:     ['rgba(90,154,90,.1)',   '#3a7a3a', 'rgba(90,154,90,.2)'],
  'in-progress': ['rgba(184,134,11,.1)',  '#8a6200', 'rgba(184,134,11,.2)'],
  pending:       ['rgba(164,89,74,.1)',   '#A4594A', 'rgba(164,89,74,.2)'],
  cancelled:     ['rgba(192,80,80,.1)',   '#c05050', 'rgba(192,80,80,.2)'],
};

export const PAY_COLORS: Record<PaymentStatus, [string, string, string]> = {
  paid:     ['rgba(90,154,90,.1)',   '#3a7a3a', 'rgba(90,154,90,.2)'],
  partial:  ['rgba(184,134,11,.1)',  '#8a6200', 'rgba(184,134,11,.2)'],
  unpaid:   ['rgba(192,80,80,.1)',   '#c05050', 'rgba(192,80,80,.2)'],
  refunded: ['rgba(164,89,74,.1)',   '#A4594A', 'rgba(164,89,74,.2)'],
};
