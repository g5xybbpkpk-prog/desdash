import { useApp } from '@/context/AppContext'
import { Sidebar } from '@/components/layout/Sidebar'
import { Topbar } from '@/components/layout/Topbar'
import { Toast } from '@/components/layout/Toast'
import { NewBookingModal, CustomerModal, BookingDetailModal } from '@/components/modals/Modals'
import { OverviewPanel }  from '@/components/panels/OverviewPanel'
import { BookingsPanel }  from '@/components/panels/BookingsPanel'
import { ServicesPanel }  from '@/components/panels/ServicesPanel'
import { CustomersPanel } from '@/components/panels/CustomersPanel'
import { StaffPanel }     from '@/components/panels/StaffPanel'
import { AnalyticsPanel } from '@/components/panels/AnalyticsPanel'
import {
  WaitlistPanel, DocumentsPanel, ReviewsPanel, SettingsPanel, AuditPanel,
} from '@/components/panels/OtherPanels'

const PANELS = {
  overview:  <OverviewPanel />,
  bookings:  <BookingsPanel />,
  services:  <ServicesPanel />,
  customers: <CustomersPanel />,
  staff:     <StaffPanel />,
  analytics: <AnalyticsPanel />,
  waitlist:  <WaitlistPanel />,
  documents: <DocumentsPanel />,
  reviews:   <ReviewsPanel />,
  settings:  <SettingsPanel />,
  audit:     <AuditPanel />,
}

function ModalRouter() {
  const { state } = useApp()
  const { modal } = state
  if (!modal.type) return null
  if (modal.type === 'newBooking')     return <NewBookingModal />
  if (modal.type === 'customer')       return <CustomerModal custId={modal.data ?? ''} />
  if (modal.type === 'bookingDetail')  return <BookingDetailModal bookingId={modal.data ?? ''} />
  return null
}

export default function App() {
  const { state } = useApp()

  return (
    <div className="flex min-h-screen overflow-hidden" style={{ background: '#FAF4EE' }}>
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden h-screen">
        <Topbar />
        <main className="flex-1 overflow-y-auto p-8" style={{ background: '#FAF4EE' }}>
          {PANELS[state.nav]}
        </main>
      </div>
      <ModalRouter />
      <Toast />
    </div>
  )
}
