import { useApp } from '@/context/AppContext'
import { TODAY } from '@/data/seed'
import { avColor, initials } from '@/utils'
import { Eyebrow, SectionTitle, GoldLine, BtnOutline } from '@/components/ui'

export function StaffPanel() {
  const { state, addLeave } = useApp()

  const handleAddLeave = (staffId: string) => {
    const date   = window.prompt('Leave date (YYYY-MM-DD):', TODAY)
    if (!date) return
    const type   = window.prompt('Type (full/morning/afternoon):', 'full')
    if (!type) return
    const reason = window.prompt('Reason:', 'Personal') ?? ''
    addLeave(staffId, date, type, reason)
  }

  return (
    <div>
      <Eyebrow>Team Management</Eyebrow>
      <SectionTitle>Staff <em className="italic text-rose">Roster</em></SectionTitle>
      <GoldLine />
      <div className="grid grid-cols-2 gap-[2px]">
        {state.staff.map((s, i) => {
          const onLeave = s.leaves.some(l => l.date === TODAY)
          const bkCount = state.bookings.filter(b => b.thId === s.id && b.date === TODAY && b.status !== 'cancelled').length
          return (
            <div
              key={s.id}
              className="border p-6"
              style={{
                background: i % 2 === 0 ? '#fff' : '#F2DDD5',
                borderColor: 'rgba(201,137,122,0.15)',
              }}
            >
              <div className="flex items-center gap-3.5 mb-4">
                <div
                  className="w-[50px] h-[50px] rounded-full flex items-center justify-center text-[15px] flex-shrink-0 text-cream tracking-[1px]"
                  style={{ background: avColor(i) }}
                >
                  {initials(s.name)}
                </div>
                <div className="flex-1">
                  <div className="font-display text-[1.1rem] font-normal text-dark">{s.name}</div>
                  <div className="text-[10px] text-muted tracking-[2px] uppercase mt-0.5">{s.role}</div>
                  <div className="font-editorial italic text-[14px] text-gold mt-0.5">
                    {'★'.repeat(Math.floor(s.rating))} {s.rating}
                  </div>
                </div>
                <span className={`text-[9px] tracking-[2px] uppercase ${onLeave ? 'text-red-600' : 'text-green-700'}`}>
                  {onLeave ? 'On Leave' : 'Available'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[12px] pt-3"
                style={{ borderTop: '1px solid rgba(201,137,122,0.15)' }}>
                <div>
                  <div className="text-[9px] tracking-[2px] uppercase text-gold mb-1">Specialisation</div>
                  <div className="text-mauve font-light">{s.spec}</div>
                </div>
                <div>
                  <div className="text-[9px] tracking-[2px] uppercase text-gold mb-1">Today's Bookings</div>
                  <div className="text-dark font-normal">{bkCount}</div>
                </div>
              </div>

              {s.leaves.length > 0 && (
                <div className="mt-3 pt-3" style={{ borderTop: '1px solid rgba(201,137,122,0.15)' }}>
                  <div className="eyebrow mb-2">Leave Record</div>
                  {s.leaves.map((l, li) => (
                    <div key={li} className="flex justify-between text-[12px] py-1 text-mauve">
                      <span>{l.date} · <span className="capitalize">{l.type}</span></span>
                      <span className="text-muted">{l.reason}</span>
                    </div>
                  ))}
                </div>
              )}

              <BtnOutline className="mt-3.5" onClick={() => handleAddLeave(s.id)}>
                + Mark Leave
              </BtnOutline>
            </div>
          )
        })}
      </div>
    </div>
  )
}
