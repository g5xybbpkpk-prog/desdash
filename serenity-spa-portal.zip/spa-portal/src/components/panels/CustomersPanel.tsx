import { useApp } from '@/context/AppContext'
import { fmtINR, avColor, initials } from '@/utils'
import { Card, Eyebrow, SectionTitle, GoldLine, BtnOutline, Table, Th, Td } from '@/components/ui'

export function CustomersPanel() {
  const { state, openModal } = useApp()

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <div>
          <Eyebrow>Client Database</Eyebrow>
          <SectionTitle className="mb-0">Customer <em className="italic text-rose">Profiles</em></SectionTitle>
        </div>
        <span className="text-[11px] text-muted">{state.customers.length} clients</span>
      </div>
      <GoldLine />
      <Table>
        <thead>
          <tr>
            {['Client','Contact','Preferences','Allergy','Visits','Total Spend',''].map(h => (
              <Th key={h}>{h}</Th>
            ))}
          </tr>
        </thead>
        <tbody>
          {state.customers.map((c, i) => (
            <tr key={c.id} style={{ background: i % 2 === 0 ? '#fff' : '#F2DDD5' }}>
              <Td>
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-[34px] h-[34px] rounded-full flex items-center justify-center text-[10px] flex-shrink-0 text-cream tracking-[1px]"
                    style={{ background: avColor(i) }}
                  >
                    {initials(c.name)}
                  </div>
                  <div>
                    <div className="text-dark font-normal">{c.name}</div>
                    <div className="text-[10px] text-muted">{c.email}</div>
                  </div>
                </div>
              </Td>
              <Td>{c.phone}</Td>
              <Td><span className="text-[12px]">{c.pref}</span></Td>
              <Td>
                {c.allergy !== 'None' ? (
                  <span
                    className="text-[9px] tracking-[1px] uppercase px-2 py-1"
                    style={{ background:'rgba(184,134,11,.1)', color:'#8a6200', border:'1px solid rgba(184,134,11,.2)' }}
                  >
                    {c.allergy}
                  </span>
                ) : <span className="text-muted">—</span>}
              </Td>
              <Td><span className="text-dark font-normal">{c.visits}</span></Td>
              <Td>
                <span className="font-editorial italic text-[15px]" style={{ color: '#A4594A' }}>
                  {fmtINR(c.spend)}
                </span>
              </Td>
              <Td>
                <BtnOutline onClick={() => openModal('customer', c.id)}>View</BtnOutline>
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Card>
  )
}
