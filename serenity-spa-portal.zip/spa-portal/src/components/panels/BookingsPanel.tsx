import { useApp } from '@/context/AppContext'
import { TODAY } from '@/data/seed'
import { fmtINR } from '@/utils'
import { Card, Eyebrow, SectionTitle, GoldLine, BtnPrimary, BtnDanger, BtnWarn, StatusTag, PayTag, Table, Th, Td } from '@/components/ui'

export function BookingsPanel() {
  const { state, openModal, cancelBooking, markPaid } = useApp()
  const reversed = [...state.bookings].reverse()

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <div>
          <Eyebrow>All Bookings</Eyebrow>
          <SectionTitle className="mb-0">Booking <em className="italic text-rose">Management</em></SectionTitle>
        </div>
        <BtnPrimary onClick={() => openModal('newBooking')}>+ New Booking</BtnPrimary>
      </div>
      <GoldLine />
      <Table>
        <thead>
          <tr>
            {['ID','Client','Service','Therapist','Date','Time','Status','Payment','Amount','Actions'].map(h => (
              <Th key={h}>{h}</Th>
            ))}
          </tr>
        </thead>
        <tbody>
          {reversed.map((b, i) => (
            <tr key={b.id} style={{ background: i % 2 === 0 ? '#fff' : '#F2DDD5' }}>
              <Td><span className="font-mono text-[11px] text-muted">{b.id}</span></Td>
              <Td><span className="text-dark font-normal">{b.name}</span></Td>
              <Td>{b.svc}</Td>
              <Td>{b.th}</Td>
              <Td>
                <span style={{ color: b.date === TODAY ? '#A4594A' : '#7A4A4A' }}>
                  {b.date === TODAY ? 'Today' : b.date}
                </span>
              </Td>
              <Td><span className="font-editorial italic text-[14px] text-gold">{b.time}</span></Td>
              <Td><StatusTag status={b.status} /></Td>
              <Td><PayTag status={b.pay} /></Td>
              <Td><span className="text-dark font-normal">{fmtINR(b.amt)}</span></Td>
              <Td>
                <div className="flex gap-1.5 items-center">
                  {b.status !== 'cancelled' && (
                    <BtnDanger onClick={() => cancelBooking(b.id)}>Cancel</BtnDanger>
                  )}
                  {b.pay === 'unpaid' && b.status !== 'cancelled' && (
                    <BtnWarn onClick={() => markPaid(b.id)}>Mark Paid</BtnWarn>
                  )}
                  {b.status === 'cancelled' && (
                    <span className="text-[10px] text-muted">—</span>
                  )}
                </div>
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Card>
  )
}
