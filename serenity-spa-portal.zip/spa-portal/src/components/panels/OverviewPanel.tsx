import { useApp } from '@/context/AppContext'
import { TODAY } from '@/data/seed'
import { fmtINR, avColor, initials } from '@/utils'
import { StatCard, StatusTag, PayTag, GoldLine, Eyebrow, SectionTitle, BtnPrimary, Card } from '@/components/ui'

export function OverviewPanel() {
  const { state, openModal, cancelBooking, markPaid } = useApp()
  const { bookings, staff } = state

  const todayBks  = bookings.filter(b => b.date === TODAY && b.status !== 'cancelled')
  const revenue   = todayBks.filter(b => b.pay === 'paid').reduce((s, b) => s + b.amt, 0)
  const pending   = todayBks.filter(b => b.status === 'pending').length
  const confirmed = todayBks.filter(b => b.status === 'confirmed').length
  const onDuty    = staff.filter(s => !s.leaves.some(l => l.date === TODAY && l.type === 'full')).length

  return (
    <div>
      {/* Stats */}
      <div className="grid grid-cols-4 gap-[2px] mb-[2px]">
        <StatCard label="Today's Bookings" value={todayBks.length}  sub={`${confirmed} confirmed · ${pending} pending`} />
        <StatCard label="Revenue Collected" value={fmtINR(revenue)} sub="Today's payments"  linen valueColor="#A4594A" />
        <StatCard label="Registered Clients" value={state.customers.length} sub="Total database" />
        <StatCard label="Staff on Duty"
          value={<>{onDuty}<span className="text-[.9rem] text-muted"> / {staff.length}</span></>}
          sub="Available today" linen
        />
      </div>

      <div className="grid gap-[2px]" style={{ gridTemplateColumns: '1fr 320px' }}>
        {/* Schedule */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <div>
              <Eyebrow>Today's Schedule</Eyebrow>
              <SectionTitle className="mb-0">Morning through <em className="italic text-rose">Evening</em></SectionTitle>
            </div>
            <BtnPrimary onClick={() => openModal('newBooking')}>+ New Booking</BtnPrimary>
          </div>
          <GoldLine />

          {/* Header row */}
          <div className="grid gap-2 px-4 py-2.5 text-[9px] tracking-[3px] uppercase font-normal"
            style={{ gridTemplateColumns: '80px 1fr 160px 120px 90px 100px 100px 110px', background:'#2E1A1A', color:'#D4AF7A' }}>
            {['ID','Client','Service','Therapist','Time','Status','Payment',''].map(h => <div key={h}>{h}</div>)}
          </div>

          {todayBks.map((b, i) => (
            <div
              key={b.id}
              className="grid gap-2 px-4 py-3 text-[12px] cursor-pointer transition-colors hover:bg-rose/5"
              style={{
                gridTemplateColumns: '80px 1fr 160px 120px 90px 100px 100px 110px',
                background: i % 2 === 0 ? '#fff' : '#F2DDD5',
                borderBottom: '1px solid rgba(201,137,122,0.15)',
              }}
              onClick={() => openModal('bookingDetail', b.id)}
            >
              <div className="font-mono text-[10px] text-muted">{b.id}</div>
              <div className="text-dark font-normal">{b.name}</div>
              <div className="text-mauve">{b.svc}</div>
              <div className="text-mauve">{b.th}</div>
              <div className="font-editorial italic text-[14px] text-gold">{b.time}</div>
              <div><StatusTag status={b.status} /></div>
              <div><PayTag status={b.pay} /></div>
              <div className="flex gap-1.5 items-center">
                {b.status !== 'cancelled' && (
                  <button className="text-[9px] text-red-600 underline cursor-pointer bg-none border-none"
                    onClick={e => { e.stopPropagation(); cancelBooking(b.id) }}>Cancel</button>
                )}
                {b.pay === 'unpaid' && b.status !== 'cancelled' && (
                  <button className="text-[9px] text-amber-700 underline cursor-pointer bg-none border-none"
                    onClick={e => { e.stopPropagation(); markPaid(b.id) }}>Pay</button>
                )}
              </div>
            </div>
          ))}
        </Card>

        {/* Staff panel */}
        <Card linen>
          <Eyebrow>Staff Status</Eyebrow>
          <SectionTitle>Today's <em className="italic text-rose">Team</em></SectionTitle>
          <GoldLine />
          {staff.map((s, i) => {
            const onLeave  = s.leaves.some(l => l.date === TODAY)
            const bkCount  = bookings.filter(b => b.thId === s.id && b.date === TODAY && b.status !== 'cancelled').length
            return (
              <div key={s.id} className="flex items-center gap-3 py-3"
                style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 text-[11px] tracking-[1px] text-cream"
                  style={{ background: avColor(i) }}>
                  {initials(s.name)}
                </div>
                <div className="flex-1">
                  <div className="text-[13px] text-dark font-normal">{s.name}</div>
                  <div className="text-[10px] text-muted tracking-[1px]">{s.role}</div>
                </div>
                <div className="text-right">
                  <div className={`text-[9px] tracking-[1px] uppercase ${onLeave ? 'text-red-600' : 'text-green-700'}`}>
                    {onLeave ? 'On Leave' : 'Available'}
                  </div>
                  <div className="text-[10px] text-muted mt-0.5">{bkCount} booking{bkCount !== 1 ? 's' : ''}</div>
                </div>
              </div>
            )
          })}
        </Card>
      </div>
    </div>
  )
}
