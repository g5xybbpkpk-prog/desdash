import { useApp } from '@/context/AppContext'
import { fmtINR } from '@/utils'
import { Eyebrow, SectionTitle, GoldLine } from '@/components/ui'

export function ServicesPanel() {
  const { state } = useApp()

  return (
    <div>
      <Eyebrow>Services & Availability</Eyebrow>
      <SectionTitle>Slot <em className="italic text-rose">Management</em></SectionTitle>
      <GoldLine />
      <div className="flex flex-col gap-[2px]">
        {state.services.map((s, i) => (
          <div
            key={s.id}
            className="border p-6"
            style={{
              background: i % 2 === 0 ? '#fff' : '#F2DDD5',
              borderColor: 'rgba(201,137,122,0.15)',
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="font-display text-[1.1rem] font-normal text-dark">{s.name}</div>
                <div className="text-[11px] text-muted mt-1 tracking-[1px]">
                  {s.cat} · {s.dur} · <span className="text-gold">{fmtINR(s.price)}</span>
                </div>
              </div>
              <span
                className="text-[9px] tracking-[2px] uppercase px-2.5 py-1"
                style={{
                  background: s.active ? 'rgba(90,154,90,.1)' : 'rgba(176,144,128,.08)',
                  color:      s.active ? '#3a7a3a'            : '#B09080',
                  border:     `1px solid ${s.active ? 'rgba(90,154,90,.2)' : 'rgba(201,137,122,0.15)'}`,
                }}
              >
                {s.active ? 'Active' : 'Inactive'}
              </span>
            </div>

            <div className="flex flex-wrap gap-0.5">
              {s.slots.map(sl => {
                const full = sl.conf + sl.holds >= sl.cap
                return (
                  <span
                    key={sl.time}
                    className={`slot-pill ${full ? 'slot-pill-full' : ''}`}
                    title={`${sl.conf}/${sl.cap} confirmed${sl.holds ? ` · ${sl.holds} hold(s)` : ''}${sl.wl.length ? ` · ${sl.wl.length} waitlist` : ''}`}
                  >
                    {sl.time}
                    <span className="opacity-60 text-[9px]">
                      {' '}{sl.conf}/{sl.cap}
                      {sl.holds ? `+${sl.holds}` : ''}
                      {sl.wl.length ? ` ·${sl.wl.length}WL` : ''}
                    </span>
                  </span>
                )
              })}
            </div>

            <div className="mt-3 pt-2.5 text-[10px] text-muted tracking-[1px]"
              style={{ borderTop: '1px solid rgba(201,137,122,0.15)' }}>
              Slots: {s.slots.length} · Confirmed: {s.slots.reduce((a, sl) => a + sl.conf, 0)} · Holds:{' '}
              {s.slots.reduce((a, sl) => a + sl.holds, 0)} · Waitlist:{' '}
              {s.slots.reduce((a, sl) => a + sl.wl.length, 0)}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
