import { useApp } from '@/context/AppContext'
import { fmtINR } from '@/utils'
import { Card, Eyebrow, SectionTitle, GoldLine, BtnDanger, Table, Th, Td } from '@/components/ui'

// ── WaitlistPanel ─────────────────────────────────────────────────────────────
export function WaitlistPanel() {
  const { state, removeWaitlist } = useApp()

  const wlItems: { svc: string; svcId: string; time: string; cid: string; cName: string; pos: number; full: boolean }[] = []
  state.services.forEach(s =>
    s.slots.forEach(sl => {
      if (sl.wl.length > 0) {
        sl.wl.forEach((cid, i) => {
          const c = state.customers.find(x => x.id === cid)
          wlItems.push({ svc: s.name, svcId: s.id, time: sl.time, cid, cName: c?.name ?? cid, pos: i + 1, full: sl.conf + sl.holds >= sl.cap })
        })
      }
    })
  )

  return (
    <Card>
      <Eyebrow>Queue Management</Eyebrow>
      <SectionTitle>Waitlist <em className="italic text-rose">Tracker</em></SectionTitle>
      <GoldLine />
      {wlItems.length === 0 ? (
        <div className="py-8 text-center font-editorial italic text-[18px] text-muted">
          No clients on waitlist
        </div>
      ) : (
        <Table>
          <thead>
            <tr>{['Position','Client','Service','Slot','Slot Status','Action'].map(h => <Th key={h}>{h}</Th>)}</tr>
          </thead>
          <tbody>
            {wlItems.map((w, i) => (
              <tr key={`${w.svcId}-${w.time}-${w.cid}`} style={{ background: i % 2 === 0 ? '#fff' : '#F2DDD5' }}>
                <Td><span className="font-editorial italic text-[18px] text-gold">#{w.pos}</span></Td>
                <Td><span className="text-dark font-normal">{w.cName}</span></Td>
                <Td>{w.svc}</Td>
                <Td><span className="font-editorial italic text-[14px] text-gold">{w.time}</span></Td>
                <Td>
                  <span className={`text-[9px] tracking-[1px] uppercase ${w.full ? 'text-red-600' : 'text-green-700'}`}>
                    {w.full ? 'Full' : 'Available'}
                  </span>
                </Td>
                <Td>
                  <BtnDanger onClick={() => removeWaitlist(w.svcId, w.time, w.cid)}>Remove</BtnDanger>
                </Td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Card>
  )
}

// ── DocumentsPanel ────────────────────────────────────────────────────────────
const DOC_CFG = {
  verified: { fg: '#3a7a3a', bg: 'rgba(90,154,90,.1)',   border: 'rgba(90,154,90,.2)',   label: '✔ Verified' },
  expiring: { fg: '#8a6200', bg: 'rgba(184,134,11,.1)',  border: 'rgba(184,134,11,.2)',  label: '⚠ Expiring' },
  pending:  { fg: '#c05050', bg: 'rgba(192,80,80,.1)',   border: 'rgba(192,80,80,.2)',   label: '⊘ Pending' },
}

export function DocumentsPanel() {
  const { state } = useApp()
  return (
    <Card>
      <Eyebrow>Compliance & Licensing</Eyebrow>
      <SectionTitle>Business <em className="italic text-rose">Documents</em></SectionTitle>
      <GoldLine />
      <Table>
        <thead>
          <tr>{['Document Name','Category','Status','Expiry'].map(h => <Th key={h}>{h}</Th>)}</tr>
        </thead>
        <tbody>
          {state.documents.map((d, i) => {
            const cfg = DOC_CFG[d.status]
            return (
              <tr key={d.id} style={{ background: i % 2 === 0 ? '#fff' : '#F2DDD5' }}>
                <Td><span className="text-dark font-normal">{d.name}</span></Td>
                <Td><span className="text-[9px] tracking-[2px] uppercase text-muted">{d.type}</span></Td>
                <Td>
                  <span className="text-[9px] tracking-[1px] uppercase px-2.5 py-1"
                    style={{ background: cfg.bg, color: cfg.fg, border: `1px solid ${cfg.border}` }}>
                    {cfg.label}
                  </span>
                </Td>
                <Td>
                  <span className="font-editorial italic text-[14px]"
                    style={{ color: d.status === 'expiring' ? '#A4594A' : '#7A4A4A' }}>
                    {d.expiry}
                  </span>
                </Td>
              </tr>
            )
          })}
        </tbody>
      </Table>
    </Card>
  )
}

// ── ReviewsPanel ──────────────────────────────────────────────────────────────
export function ReviewsPanel() {
  const { state } = useApp()
  const avg = (state.reviews.reduce((s, r) => s + r.rating, 0) / state.reviews.length).toFixed(1)

  return (
    <div className="grid gap-[2px]" style={{ gridTemplateColumns: '220px 1fr', alignItems: 'start' }}>
      {/* Score card */}
      <div className="border p-8 text-center" style={{ background: '#2E1A1A', borderColor: 'rgba(212,175,122,0.12)' }}>
        <div className="eyebrow" style={{ color: 'rgba(212,175,122,.5)' }}>Average Rating</div>
        <div className="font-display text-[3.5rem] font-light text-cream leading-none">{avg}</div>
        <div className="text-gold text-[1.3rem] my-2 tracking-[4px]">{'★'.repeat(Math.round(Number(avg)))}</div>
        <div className="text-[10px] tracking-[2px]" style={{ color: 'rgba(212,175,122,0.4)' }}>
          {state.reviews.length} REVIEWS
        </div>
        <div className="mt-5">
          {[5, 4, 3, 2, 1].map(r => {
            const cnt = state.reviews.filter(rv => rv.rating === r).length
            const pct = Math.round((cnt / state.reviews.length) * 100)
            return (
              <div key={r} className="flex items-center gap-2 mb-1.5">
                <span className="text-[10px] w-3" style={{ color: 'rgba(212,175,122,.5)' }}>{r}</span>
                <div className="flex-1 h-[3px] overflow-hidden" style={{ background: 'rgba(255,255,255,.08)' }}>
                  <div className="h-full" style={{ width: `${pct}%`, background: '#D4AF7A' }} />
                </div>
                <span className="text-[10px] w-4" style={{ color: 'rgba(212,175,122,0.4)' }}>{cnt}</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Review list */}
      <div>
        <div className="eyebrow mb-3">Guest Reviews</div>
        {state.reviews.map(r => (
          <div key={r.id} className="border p-5 mb-[2px]"
            style={{ background: r.rating === 5 ? '#fff' : '#F2DDD5', borderColor: 'rgba(201,137,122,0.15)' }}>
            <div className="flex justify-between items-start mb-2.5">
              <div>
                <div className="text-[14px] text-dark font-normal">{r.client}</div>
                <div className="text-[10px] text-muted tracking-[1px] mt-0.5">{r.service} · {r.date}</div>
              </div>
              <div className="text-gold tracking-[2px]">
                {'★'.repeat(r.rating)}<span className="text-linen">{'★'.repeat(5 - r.rating)}</span>
              </div>
            </div>
            <div className="font-editorial italic text-[15px] text-mauve leading-[1.7]">"{r.text}"</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── SettingsPanel ─────────────────────────────────────────────────────────────
export function SettingsPanel() {
  const { state } = useApp()
  const s = state.settings
  const infoRows: [string, string][] = [
    ['Spa Name', s.spaName], ['Owner', s.owner], ['Phone', s.phone],
    ['Email', s.email], ['City', s.city], ['Description', s.desc],
  ]
  return (
    <div>
      <Eyebrow>Configuration</Eyebrow>
      <SectionTitle>Spa <em className="italic text-rose">Settings</em></SectionTitle>
      <GoldLine />
      <div className="grid grid-cols-2 gap-[2px]">
        <Card>
          <Eyebrow>Spa Information</Eyebrow>
          <div className="flex flex-col gap-3.5">
            {infoRows.map(([k, v]) => (
              <div key={k} className="pb-3" style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
                <div className="text-[9px] tracking-[3px] uppercase text-gold mb-1">{k}</div>
                <div className="text-[13px] text-mauve font-light">{v}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card linen>
          <Eyebrow>Operating Hours</Eyebrow>
          <div className="flex flex-col gap-3.5">
            {[['Opening Time', s.open], ['Closing Time', s.close], ['Hold Duration', `${s.holdDuration} seconds`]].map(([k, v]) => (
              <div key={k} className="pb-3" style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
                <div className="text-[9px] tracking-[3px] uppercase text-gold mb-1">{k}</div>
                <div className="font-editorial italic text-[16px] text-dark">{v}</div>
              </div>
            ))}
            <div>
              <Eyebrow className="mb-2.5">Notification Preferences</Eyebrow>
              {(Object.entries({ bookings: 'New Bookings', reviews: 'New Reviews', documents: 'Document Alerts', payments: 'Payment Updates' }) as [keyof typeof s.notif, string][]).map(([k, label]) => (
                <div key={k} className="flex justify-between py-2" style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
                  <span className="text-[12px] text-mauve">{label}</span>
                  <span className="text-[9px] tracking-[1px] uppercase px-2 py-0.5"
                    style={{
                      background: s.notif[k] ? 'rgba(90,154,90,.1)' : 'rgba(176,144,128,.08)',
                      color:      s.notif[k] ? '#3a7a3a'            : '#B09080',
                      border:     `1px solid ${s.notif[k] ? 'rgba(90,154,90,.2)' : 'rgba(201,137,122,0.15)'}`,
                    }}>
                    {s.notif[k] ? 'On' : 'Off'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

// ── AuditPanel ────────────────────────────────────────────────────────────────
export function AuditPanel() {
  const { state } = useApp()
  return (
    <Card>
      <Eyebrow>System Log</Eyebrow>
      <SectionTitle>Audit <em className="italic text-rose">Trail</em>{' '}
        <span className="text-[11px] text-muted font-sans font-light">({state.audit.length} entries)</span>
      </SectionTitle>
      <GoldLine />
      <Table>
        <thead>
          <tr>{['Time','Action','Entity','Detail','By'].map(h => <Th key={h}>{h}</Th>)}</tr>
        </thead>
        <tbody>
          {state.audit.slice(0, 50).map((a, i) => (
            <tr key={a.id} style={{ background: i % 2 === 0 ? '#fff' : '#F2DDD5' }}>
              <Td><span className="font-editorial italic text-[14px] text-gold">{a.ts}</span></Td>
              <Td><span className="text-dark font-normal">{a.action}</span></Td>
              <Td><span className="font-mono text-[11px] text-muted">{a.entity}</span></Td>
              <Td className="text-[12px]">{a.detail}</Td>
              <Td><span className="text-[10px] text-muted tracking-[1px] uppercase">{a.user}</span></Td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Card>
  )
}
