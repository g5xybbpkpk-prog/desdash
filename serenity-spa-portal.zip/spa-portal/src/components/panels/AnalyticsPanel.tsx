import { useApp } from '@/context/AppContext'
import { fmtINR, avColor, initials, PAY_CONFIG } from '@/utils'
import { Card, Eyebrow, ProgressBar } from '@/components/ui'

export function AnalyticsPanel() {
  const { state } = useApp()
  const { bookings, services, customers } = state

  const byCat: Record<string, number> = { Massage: 0, Wellness: 0, Beauty: 0 }
  bookings.forEach(b => {
    const s = services.find(sv => sv.id === b.svcId)
    if (s) byCat[s.cat] = (byCat[s.cat] ?? 0) + b.amt
  })
  const catTotal = Object.values(byCat).reduce((a, v) => a + v, 0)
  const topCusts = [...customers].sort((a, b) => b.spend - a.spend).slice(0, 5)

  return (
    <div>
      <Eyebrow>Business Intelligence</Eyebrow>
      <div className="grid grid-cols-2 gap-[2px]">
        {/* Revenue by category */}
        <Card>
          <Eyebrow>Revenue by Category</Eyebrow>
          {Object.entries(byCat).map(([cat, amt]) => {
            const pct = catTotal ? Math.round((amt / catTotal) * 100) : 0
            return (
              <div key={cat} className="mb-4">
                <div className="flex justify-between text-[12px] mb-1.5">
                  <span className="text-mauve">{cat}</span>
                  <span className="font-editorial italic text-[15px] text-gold">{fmtINR(amt)}</span>
                </div>
                <ProgressBar pct={pct} color="linear-gradient(90deg,#C9897A,#A4594A)" />
                <div className="text-[10px] text-muted mt-0.5 tracking-[1px]">{pct}% of total</div>
              </div>
            )
          })}
        </Card>

        {/* Top clients */}
        <Card linen>
          <Eyebrow>Top Clients by Spend</Eyebrow>
          {topCusts.map((c, i) => (
            <div key={c.id} className="flex items-center gap-3 py-2.5"
              style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
              <div className="font-display text-[18px] font-light text-muted w-5 text-center">{i + 1}</div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] text-cream flex-shrink-0"
                style={{ background: avColor(i) }}>
                {initials(c.name)}
              </div>
              <div className="flex-1">
                <div className="text-[13px] text-dark font-normal">{c.name}</div>
                <div className="text-[10px] text-muted">{c.visits} visits</div>
              </div>
              <div className="font-editorial italic text-[16px] text-terra">{fmtINR(c.spend)}</div>
            </div>
          ))}
        </Card>

        {/* Service popularity */}
        <Card>
          <Eyebrow>Service Popularity</Eyebrow>
          {services.map(s => {
            const cnt    = bookings.filter(b => b.svcId === s.id).length
            const maxCnt = Math.max(...services.map(sv => bookings.filter(b => b.svcId === sv.id).length), 1)
            return (
              <div key={s.id} className="mb-3.5">
                <div className="flex justify-between text-[12px] mb-1.5">
                  <span className="text-mauve">{s.name}</span>
                  <span className="text-[10px] text-muted">{cnt} booking{cnt !== 1 ? 's' : ''}</span>
                </div>
                <ProgressBar pct={Math.round((cnt / maxCnt) * 100)} color="#C9897A" />
              </div>
            )
          })}
        </Card>

        {/* Payment summary */}
        <Card linen>
          <Eyebrow>Payment Summary</Eyebrow>
          {(['paid', 'partial', 'unpaid', 'refunded'] as const).map(p => {
            const cnt = bookings.filter(b => b.pay === p).length
            const amt = bookings.filter(b => b.pay === p).reduce((s, b) => s + b.amt, 0)
            const [, fg] = PAY_CONFIG[p]
            return (
              <div key={p} className="flex items-center gap-3 py-2.5"
                style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
                <div className="w-2 h-2 flex-shrink-0" style={{ background: fg }} />
                <div className="flex-1 text-[12px] text-mauve capitalize">{p}</div>
                <div className="text-[11px] text-muted">{cnt} booking{cnt !== 1 ? 's' : ''}</div>
                <div className="font-editorial italic text-[15px] text-dark">{fmtINR(amt)}</div>
              </div>
            )
          })}
        </Card>
      </div>
    </div>
  )
}
