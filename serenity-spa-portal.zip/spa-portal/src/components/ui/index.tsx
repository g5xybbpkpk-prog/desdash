import type { ReactNode, ButtonHTMLAttributes, SelectHTMLAttributes } from 'react';

// ── Eyebrow label ────────────────────────────────────────────────────────────
export function Eyebrow({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <p className={`text-[9px] tracking-[5px] uppercase text-gold font-sans font-light block mb-2.5 ${className}`}>{children}</p>;
}

// ── Section title ────────────────────────────────────────────────────────────
export function SectionTitle({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <h2 className={`font-display text-[1.1rem] font-normal text-dark mb-4 ${className}`}>{children}</h2>;
}

// ── Gold divider ─────────────────────────────────────────────────────────────
export function GoldLine() {
  return <div className="gold-line" />;
}

// ── Stat card ────────────────────────────────────────────────────────────────
export function StatCard({ label, value, sub, linen = false }: { label: string; value: ReactNode; sub?: string; linen?: boolean }) {
  return (
    <div className={`p-6 ${linen ? 'bg-linen' : 'bg-white'}`}>
      <p className="text-[9px] tracking-[4px] uppercase text-gold mb-2">{label}</p>
      <div className="font-display text-[2rem] font-light text-dark leading-none">{value}</div>
      {sub && <p className="text-[11px] text-muted mt-1.5 font-light">{sub}</p>}
    </div>
  );
}

// ── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, className = '', linen = false }: { children: ReactNode; className?: string; linen?: boolean }) {
  return (
    <div className={`border border-rose/15 p-6 ${linen ? 'bg-linen' : 'bg-white'} ${className}`}>
      {children}
    </div>
  );
}

// ── Status tag ───────────────────────────────────────────────────────────────
import { ST_COLORS, PAY_COLORS } from '../../utils';
import type { BookingStatus, PaymentStatus } from '../../types';

export function StatusTag({ status }: { status: BookingStatus }) {
  const [bg, fg, border] = ST_COLORS[status] ?? ['var(--linen)', 'var(--muted)', 'var(--border-soft)'];
  return (
    <span style={{ background: bg, color: fg, border: `1px solid ${border}` }}
      className="inline-flex px-2.5 py-0.5 text-[9px] tracking-[1px] uppercase">
      {status}
    </span>
  );
}

export function PayTag({ status }: { status: PaymentStatus }) {
  const [bg, fg, border] = PAY_COLORS[status] ?? ['var(--linen)', 'var(--muted)', 'var(--border-soft)'];
  return (
    <span style={{ background: bg, color: fg, border: `1px solid ${border}` }}
      className="inline-flex px-2.5 py-0.5 text-[9px] tracking-[1px] uppercase">
      {status}
    </span>
  );
}

// ── Avatar ───────────────────────────────────────────────────────────────────
import { avColor } from '../../utils';
export function Avatar({ name, index, size = 'md' }: { name: string; index: number; size?: 'sm' | 'md' | 'lg' }) {
  const dims = size === 'sm' ? 'w-8 h-8 text-[10px]' : size === 'lg' ? 'w-12 h-12 text-[15px]' : 'w-9 h-9 text-[11px]';
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  return (
    <div className={`${dims} rounded-full flex items-center justify-center font-normal flex-shrink-0 tracking-wide text-cream`}
      style={{ background: avColor(index) }}>
      {initials}
    </div>
  );
}

// ── Button variants ───────────────────────────────────────────────────────────
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode };

export function BtnPrimary({ children, className = '', ...props }: BtnProps) {
  return (
    <button {...props}
      className={`bg-dark text-cream border-0 px-5 py-2.5 cursor-pointer font-sans text-[10px] font-normal tracking-[3px] uppercase transition-all duration-300 hover:bg-terra disabled:opacity-35 disabled:cursor-not-allowed ${className}`}>
      {children}
    </button>
  );
}

export function BtnOutline({ children, className = '', ...props }: BtnProps) {
  return (
    <button {...props}
      className={`bg-transparent border border-gold/50 text-dark px-4 py-2 cursor-pointer font-sans text-[10px] tracking-[2px] uppercase transition-all duration-300 hover:border-rose hover:text-rose ${className}`}>
      {children}
    </button>
  );
}

export function BtnGhost({ children, className = '', ...props }: BtnProps) {
  return (
    <button {...props}
      className={`bg-transparent text-mauve border border-rose px-4 py-2 cursor-pointer font-sans text-[10px] font-normal tracking-[3px] uppercase transition-all duration-300 hover:bg-rose/10 hover:text-rose ${className}`}>
      {children}
    </button>
  );
}

export function BtnDanger({ children, className = '', ...props }: BtnProps) {
  return (
    <button {...props}
      className={`bg-red/5 text-spa-red border border-red/20 px-3 py-1.5 cursor-pointer font-sans text-[10px] tracking-[1px] transition-all duration-200 hover:bg-red/15 ${className}`}>
      {children}
    </button>
  );
}

export function BtnWarn({ children, className = '', ...props }: BtnProps) {
  return (
    <button {...props}
      className={`bg-amber/5 text-spa-amber border border-amber/20 px-3 py-1.5 cursor-pointer font-sans text-[10px] tracking-[1px] transition-all duration-200 hover:bg-amber/15 ${className}`}>
      {children}
    </button>
  );
}

// ── Select input ──────────────────────────────────────────────────────────────
type SelectProps = SelectHTMLAttributes<HTMLSelectElement> & { label?: string };
export function SelectField({ label, className = '', ...props }: SelectProps) {
  return (
    <div>
      {label && <p className="text-[9px] tracking-[4px] uppercase text-gold mb-1.5">{label}</p>}
      <select {...props}
        className={`bg-cream border border-rose/15 text-dark px-3.5 py-2.5 font-sans text-[13px] font-light outline-none transition-colors w-full focus:border-terra ${className}`} />
    </div>
  );
}

// ── Progress bar ──────────────────────────────────────────────────────────────
export function ProgressBar({ pct, color = 'var(--rose)' }: { pct: number; color?: string }) {
  return (
    <div className="progress-track">
      <div className="progress-fill" style={{ width: `${pct}%`, background: color }} />
    </div>
  );
}

// ── Table wrapper ─────────────────────────────────────────────────────────────
export function Table({ children }: { children: ReactNode }) {
  return <table className="w-full border-collapse">{children}</table>;
}
export function Th({ children }: { children: ReactNode }) {
  return <th className="text-[9px] tracking-[4px] uppercase text-gold px-3.5 py-2.5 border-b border-rose/15 text-left font-normal bg-dark">{children}</th>;
}
export function Td({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <td className={`px-3.5 py-3 border-b border-rose/15 text-[13px] text-mauve font-light ${className}`}>{children}</td>;
}
