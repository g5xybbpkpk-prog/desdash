import { useState } from 'react'
import { useApp } from '@/context/AppContext'
import { TODAY } from '@/data/seed'
import { fmtINR, initials } from '@/utils'
import {
  GoldLine, Eyebrow, BtnPrimary, BtnGhost, BtnDanger, BtnWarn,
  FormField, Select, StatusTag, PayTag,
} from '@/components/ui'

// ── Modal shell ───────────────────────────────────────────────────────────────
function ModalShell({ children }: { children: React.ReactNode }) {
  const { closeModal } = useApp()
  return (
    <div
      className="fixed inset-0 flex items-center justify-center z-[200]"
      style={{ background: 'rgba(46,26,26,.6)', backdropFilter: 'blur(4px)' }}
      onClick={e => { if (e.target === e.currentTarget) closeModal() }}
    >
      <div
        className="border p-8 w-[520px] max-h-[88vh] overflow-y-auto animate-slide-in"
        style={{
          background: '#FAF4EE',
          borderColor: 'rgba(201,137,122,0.15)',
          boxShadow: '0 24px 64px rgba(46,26,26,.15)',
        }}
      >
        {children}
      </div>
    </div>
  )
}

// ── NewBookingModal ───────────────────────────────────────────────────────────
export function NewBookingModal() {
  const { state, closeModal, addBooking } = useApp()
  const [custId, setCustId] = useState(state.customers[0]?.id ?? '')
  const [svcId,  setSvcId]  = useState(state.services[0]?.id ?? '')
  const [time,   setTime]   = useState('')
  const [thId,   setThId]   = useState('')

  const availableStaff = state.staff.filter(s => !s.leaves.some(l => l.date === TODAY && l.type === 'full'))
  const currentSvc     = state.services.find(s => s.id === svcId)

  const handleSvcChange = (id: string) => {
    setSvcId(id)
    setTime('')
  }

  const handleConfirm = () => {
    if (!custId || !svcId || !time || !thId) return
    addBooking(custId, svcId, time, thId)
    closeModal()
  }

  return (
    <ModalShell>
      <div className="mb-6">
        <Eyebrow>New Booking</Eyebrow>
        <div className="font-display text-[1.5rem] font-normal text-dark">
          Reserve a <em className="italic text-rose">Slot</em>
        </div>
      </div>
      <GoldLine />

      <div className="flex flex-col gap-4">
        <FormField label="Client">
          <Select value={custId} onChange={e => setCustId(e.target.value)}>
            {state.customers.map(c => (
              <option key={c.id} value={c.id}>{c.name} · {c.phone}</option>
            ))}
          </Select>
        </FormField>

        <FormField label="Service">
          <Select value={svcId} onChange={e => handleSvcChange(e.target.value)}>
            {state.services.map(s => (
              <option key={s.id} value={s.id}>{s.name} — {fmtINR(s.price)} ({s.dur})</option>
            ))}
          </Select>
        </FormField>

        <FormField label="Time Slot">
          <Select value={time} onChange={e => setTime(e.target.value)}>
            <option value="">Select a slot…</option>
            {currentSvc?.slots.map(sl => {
              const full = sl.conf + sl.holds >= sl.cap
              return (
                <option key={sl.time} value={sl.time} disabled={full}>
                  {sl.time} ({sl.conf}/{sl.cap}){full ? ' — Full' : ''}
                </option>
              )
            })}
          </Select>
        </FormField>

        <FormField label="Therapist">
          <Select value={thId} onChange={e => setThId(e.target.value)}>
            <option value="">Select therapist…</option>
            {availableStaff.map(s => (
              <option key={s.id} value={s.id}>{s.name} — {s.role}</option>
            ))}
          </Select>
        </FormField>
      </div>

      <div className="flex gap-2.5 mt-6">
        <BtnPrimary className="flex-1" onClick={handleConfirm}
          disabled={!custId || !svcId || !time || !thId}>
          Confirm Booking
        </BtnPrimary>
        <BtnGhost className="flex-1" onClick={closeModal}>Cancel</BtnGhost>
      </div>
    </ModalShell>
  )
}

// ── CustomerModal ─────────────────────────────────────────────────────────────
export function CustomerModal({ custId }: { custId: string }) {
  const { state, closeModal } = useApp()
  const c = state.customers.find(x => x.id === custId)
  if (!c) return null
  const custBks = state.bookings.filter(b => b.cid === custId)

  return (
    <ModalShell>
      <div className="flex items-center gap-3.5 mb-6">
        <div className="w-[54px] h-[54px] rounded-full flex items-center justify-center text-[18px] text-cream flex-shrink-0"
          style={{ background: '#C9897A' }}>
          {initials(c.name)}
        </div>
        <div>
          <div className="font-display text-[1.4rem] font-normal text-dark">{c.name}</div>
          <div className="text-[11px] text-muted mt-1">{c.email} · {c.phone}</div>
        </div>
      </div>
      <GoldLine />

      <div className="grid grid-cols-2 gap-[2px] mb-5">
        <div className="p-[18px] text-center" style={{ background: '#F2DDD5' }}>
          <Eyebrow>Total Visits</Eyebrow>
          <div className="font-display text-[2rem] font-light text-dark">{c.visits}</div>
        </div>
        <div className="p-[18px] text-center" style={{ background: '#2E1A1A' }}>
          <Eyebrow style={{ color: 'rgba(212,175,122,.5)' }}>Total Spend</Eyebrow>
          <div className="font-display text-[2rem] font-light text-gold">{fmtINR(c.spend)}</div>
        </div>
      </div>

      <div className="flex flex-col gap-3 mb-5">
        <div className="pb-2.5" style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
          <Eyebrow>Preferences</Eyebrow>
          <div className="font-editorial italic text-[15px] text-mauve">{c.pref}</div>
        </div>
        {c.allergy !== 'None' && (
          <div>
            <Eyebrow>Allergy Alert</Eyebrow>
            <span className="text-[10px] px-3 py-1.5 tracking-[2px] uppercase"
              style={{ background:'rgba(184,134,11,.1)', color:'#8a6200', border:'1px solid rgba(184,134,11,.2)' }}>
              {c.allergy}
            </span>
          </div>
        )}
      </div>

      <Eyebrow className="mb-2.5">Booking History</Eyebrow>
      {custBks.length === 0 ? (
        <p className="font-editorial italic text-[14px] text-muted">No bookings recorded yet</p>
      ) : custBks.map(b => (
        <div key={b.id} className="flex justify-between items-center py-2.5 text-[12px]"
          style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
          <span className="text-mauve">{b.svc}</span>
          <span className="font-editorial italic text-[14px] text-gold">{b.time}</span>
          <StatusTag status={b.status} />
          <span className="text-terra">{fmtINR(b.amt)}</span>
        </div>
      ))}

      <BtnGhost className="mt-5 w-full text-center" onClick={closeModal}>Close</BtnGhost>
    </ModalShell>
  )
}

// ── BookingDetailModal ────────────────────────────────────────────────────────
export function BookingDetailModal({ bookingId }: { bookingId: string }) {
  const { state, closeModal, cancelBooking, markPaid } = useApp()
  const b = state.bookings.find(x => x.id === bookingId)
  if (!b) return null

  const rows: [string, React.ReactNode][] = [
    ['Client',    <span className="text-[13px] text-mauve font-light">{b.name}</span>],
    ['Service',   <span className="text-[13px] text-mauve font-light">{b.svc}</span>],
    ['Therapist', <span className="text-[13px] text-mauve font-light">{b.th}</span>],
    ['Time',      <span className="font-editorial italic text-[16px] text-gold">{b.time}</span>],
    ['Status',    <StatusTag status={b.status} />],
    ['Payment',   <PayTag status={b.pay} />],
    ['Amount',    <span className="font-editorial italic text-[1.5rem] text-terra">{fmtINR(b.amt)}</span>],
  ]

  return (
    <ModalShell>
      <div className="mb-5">
        <Eyebrow>Booking Details</Eyebrow>
        <div className="font-display text-[1.4rem] font-normal text-dark">{b.id}</div>
      </div>
      <GoldLine />

      {rows.map(([k, v]) => (
        <div key={k} className="flex justify-between items-center py-3"
          style={{ borderBottom: '1px solid rgba(201,137,122,0.15)' }}>
          <span className="text-[9px] tracking-[3px] uppercase text-gold">{k}</span>
          {v}
        </div>
      ))}

      <div className="flex gap-2 flex-wrap mt-4">
        {b.status !== 'cancelled' && (
          <BtnDanger onClick={() => { cancelBooking(b.id); closeModal() }}>Cancel Booking</BtnDanger>
        )}
        {b.pay === 'unpaid' && b.status !== 'cancelled' && (
          <BtnWarn onClick={() => { markPaid(b.id); closeModal() }}>Mark as Paid</BtnWarn>
        )}
        <BtnGhost className="ml-auto" onClick={closeModal}>Close</BtnGhost>
      </div>
    </ModalShell>
  )
}
