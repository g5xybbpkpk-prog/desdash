import { useApp } from '@/context/AppContext'

export function Toast() {
  const { state } = useApp()
  if (!state.toast) return null
  return (
    <div
      className="fixed bottom-6 right-6 flex items-center gap-2.5 px-5 py-3.5
        text-[12px] text-cream font-light z-[300] animate-slide-in max-w-[320px]"
      style={{
        background: '#2E1A1A',
        border: '1px solid rgba(212,175,122,0.2)',
        boxShadow: '0 8px 32px rgba(46,26,26,0.2)',
      }}
    >
      <span style={{ color: '#D4AF7A' }}>{state.toast.icon}</span>
      {state.toast.msg}
    </div>
  )
}
