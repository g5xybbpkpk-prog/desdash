import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { NAV_ITEMS } from '../../data/seed';
import { useApp } from '../../context/AppContext';
import { BtnGhost } from '../ui';
import { NotifDropdown } from './NotifDropdown';

interface Props { onNewBooking: () => void; }

export function Topbar({ onNewBooking }: Props) {
  const { notifications } = useApp();
  const [showNotifs, setShowNotifs] = useState(false);
  const location = useLocation();
  const path = location.pathname.slice(1) || 'overview';
  const label = NAV_ITEMS.find(n => n.id === path)?.label ?? 'Overview';
  const unread = notifications.filter(n => !n.read).length;

  return (
    <header className="h-[62px] bg-cream border-b flex items-center justify-between px-8 flex-shrink-0"
      style={{ borderColor: 'rgba(201,137,122,0.15)' }}>
      <p className="text-[9px] text-gold tracking-[5px] uppercase">{label}</p>

      <div className="flex items-center gap-3.5">
        <BtnGhost onClick={onNewBooking}>+ New Booking</BtnGhost>
        <BtnGhost>◎ Customer Portal</BtnGhost>

        {/* Notifications */}
        <div className="relative">
          <button onClick={() => setShowNotifs(v => !v)}
            className="w-9 h-9 flex items-center justify-center text-[15px] relative transition-all duration-200 border text-muted hover:border-rose hover:text-rose bg-transparent cursor-pointer"
            style={{ borderColor: 'rgba(201,137,122,0.15)' }}>
            🔔
            {unread > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-terra border-2 border-cream" />
            )}
          </button>
          {showNotifs && <NotifDropdown onClose={() => setShowNotifs(false)} />}
        </div>

        <div className="w-px h-5" style={{ background: 'rgba(201,137,122,0.15)' }} />

        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-cream text-[11px] tracking-wide bg-rose">SS</div>
          <div>
            <p className="font-display text-[13px] text-dark">Serenity Spa</p>
            <p className="text-[9px] text-muted tracking-[2px] uppercase">Admin</p>
          </div>
        </div>
      </div>
    </header>
  );
}
