import { NavLink } from 'react-router-dom';
import { NAV_ITEMS } from '../../data/seed';

interface Props { collapsed: boolean; onToggle: () => void; }

export function Sidebar({ collapsed, onToggle }: Props) {
  return (
    <aside
      className="flex-shrink-0 bg-dark border-r flex flex-col h-screen sticky top-0 overflow-hidden transition-all duration-300"
      style={{ width: collapsed ? 58 : 236, borderColor: 'rgba(212,175,122,0.12)' }}>

      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-6" style={{ borderBottom: '1px solid rgba(212,175,122,0.12)' }}>
        <span className="font-display text-[22px] font-normal tracking-[6px] text-cream flex-shrink-0 pr-1.5">
          R<span className="text-gold">A</span>RE
        </span>
        {!collapsed && (
          <span className="text-[8px] tracking-[3px] uppercase" style={{ color: 'rgba(212,175,122,0.4)' }}>
            Partner Portal
          </span>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-3 overflow-y-auto">
        {NAV_ITEMS.map(item => (
          <NavLink key={item.id} to={`/${item.id === 'overview' ? '' : item.id}`} end={item.id === 'overview'}
            className={({ isActive }) =>
              `flex items-center gap-2.5 px-4 py-2.5 rounded cursor-pointer transition-all duration-200 border-none w-full text-left whitespace-nowrap text-[12px] font-light tracking-[0.5px] no-underline
               ${isActive
                 ? 'bg-gold/10 text-gold'
                 : 'text-cream/45 hover:bg-gold/8 hover:text-gold'}`
            }>
            <span className="text-[13px] w-[18px] text-center flex-shrink-0 opacity-70">{item.ic}</span>
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Status */}
      {!collapsed && (
        <div className="px-5 py-4" style={{ borderTop: '1px solid rgba(212,175,122,0.1)' }}>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-spa-green" />
            <span className="text-[10px] tracking-[1px]" style={{ color: 'rgba(212,175,122,0.4)' }}>
              Open · Closes 9 PM
            </span>
          </div>
        </div>
      )}

      {/* Collapse button */}
      <button onClick={onToggle}
        className="font-mono text-[14px] text-center w-full py-2.5 bg-transparent border-0 cursor-pointer transition-colors duration-200 hover:text-gold"
        style={{ color: 'rgba(212,175,122,0.3)', borderTop: '1px solid rgba(212,175,122,0.08)' }}>
        {collapsed ? '›' : '‹'}
      </button>
    </aside>
  );
}
