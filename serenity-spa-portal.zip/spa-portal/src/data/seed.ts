import type { Customer, Service, Booking, StaffMember, Document, Review, SpaSettings, AuditEntry } from '../types';

const getToday = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
};
export const TODAY = getToday();

export const INIT_CUSTOMERS: Customer[] = [
  { id:'c1', name:'Priya Sharma',  phone:'+91 98765 43210', email:'priya@email.com',  dob:'1990-03-15', pref:'Deep tissue, firm pressure', allergy:'Lavender oil', visits:8, spend:24600, guest:false },
  { id:'c2', name:'Rohan Mehta',   phone:'+91 87654 32109', email:'rohan@email.com',  dob:'1985-07-22', pref:'Swedish, medium pressure',   allergy:'None',        visits:3, spend:6800,  guest:false },
  { id:'c3', name:'Sunita Patel',  phone:'+91 76543 21098', email:'sunita@email.com', dob:'1992-11-08', pref:'Facials, hydrating',          allergy:'Nuts',        visits:5, spend:18200, guest:false },
  { id:'c4', name:'Arjun Nair',    phone:'+91 65432 10987', email:'arjun@email.com',  dob:'1988-05-30', pref:'Hot stone, full body',        allergy:'None',        visits:2, spend:7100,  guest:false },
  { id:'c5', name:'Meera Iyer',    phone:'+91 54321 09876', email:'meera@email.com',  dob:'1995-09-12', pref:'Aromatherapy, light touch',   allergy:'Peppermint',  visits:6, spend:15400, guest:false },
  { id:'c6', name:'Vikram Singh',  phone:'+91 43210 98765', email:'vikram@email.com', dob:'1982-12-03', pref:'Couples massage',             allergy:'None',        visits:1, spend:4000,  guest:false },
];

export const INIT_SERVICES: Service[] = [
  { id:'s1', name:'Swedish Massage',     cat:'Massage', dur:'60 min',  price:1500, active:true, slots:[{time:'10:00 AM',cap:2,conf:2,holds:0,wl:[]},{time:'12:00 PM',cap:2,conf:1,holds:1,wl:['c3']},{time:'02:00 PM',cap:2,conf:0,holds:0,wl:[]},{time:'04:00 PM',cap:2,conf:1,holds:0,wl:[]}] },
  { id:'s2', name:'Deep Tissue Massage', cat:'Massage', dur:'90 min',  price:1800, active:true, slots:[{time:'10:00 AM',cap:1,conf:1,holds:0,wl:['c2']},{time:'12:00 PM',cap:1,conf:0,holds:1,wl:[]},{time:'03:00 PM',cap:1,conf:0,holds:0,wl:[]}] },
  { id:'s3', name:'Hot Stone Therapy',   cat:'Massage', dur:'75 min',  price:2500, active:true, slots:[{time:'11:00 AM',cap:2,conf:1,holds:0,wl:[]},{time:'02:00 PM',cap:2,conf:2,holds:0,wl:['c4','c5']},{time:'05:00 PM',cap:2,conf:0,holds:0,wl:[]}] },
  { id:'s4', name:'Aromatherapy',        cat:'Wellness',dur:'60 min',  price:1600, active:true, slots:[{time:'10:00 AM',cap:3,conf:2,holds:1,wl:[]},{time:'01:00 PM',cap:3,conf:1,holds:0,wl:[]},{time:'04:00 PM',cap:3,conf:0,holds:0,wl:[]}] },
  { id:'s5', name:'Facial + Body Wrap',  cat:'Beauty',  dur:'120 min', price:3200, active:true, slots:[{time:'10:00 AM',cap:1,conf:1,holds:0,wl:['c1']},{time:'01:00 PM',cap:1,conf:0,holds:0,wl:[]}] },
  { id:'s6', name:'Head Spa Treatment',  cat:'Beauty',  dur:'45 min',  price:1200, active:true, slots:[{time:'09:00 AM',cap:2,conf:1,holds:0,wl:[]},{time:'11:00 AM',cap:2,conf:2,holds:0,wl:['c6']},{time:'02:00 PM',cap:2,conf:1,holds:1,wl:[]},{time:'04:00 PM',cap:2,conf:0,holds:0,wl:[]}] },
];

export const INIT_BOOKINGS: Booking[] = [
  { id:'BK001', cid:'c1', name:'Priya Sharma', svcId:'s2', svc:'Deep Tissue Massage', th:'Anjali K.',  thId:'st1', time:'10:00 AM', date:TODAY, status:'confirmed',    pay:'paid',    amt:1800 },
  { id:'BK002', cid:'c2', name:'Rohan Mehta',  svcId:'s1', svc:'Swedish Massage',     th:'Deepa R.',   thId:'st2', time:'12:00 PM', date:TODAY, status:'in-progress',  pay:'paid',    amt:1500 },
  { id:'BK003', cid:'c3', name:'Sunita Patel', svcId:'s5', svc:'Facial + Body Wrap',  th:'Kavya S.',   thId:'st3', time:'02:00 PM', date:TODAY, status:'pending',      pay:'unpaid',  amt:3200 },
  { id:'BK004', cid:'c4', name:'Arjun Nair',   svcId:'s3', svc:'Hot Stone Therapy',   th:'Anjali K.',  thId:'st1', time:'04:00 PM', date:TODAY, status:'confirmed',    pay:'partial', amt:2500 },
  { id:'BK005', cid:'c5', name:'Meera Iyer',   svcId:'s4', svc:'Aromatherapy',        th:'Deepa R.',   thId:'st2', time:'10:00 AM', date:TODAY, status:'confirmed',    pay:'paid',    amt:1600 },
  { id:'BK006', cid:'c6', name:'Vikram Singh', svcId:'s1', svc:'Swedish Massage',     th:'Kavya S.',   thId:'st3', time:'04:00 PM', date:TODAY, status:'confirmed',    pay:'unpaid',  amt:1500 },
];

export const INIT_STAFF: StaffMember[] = [
  { id:'st1', name:'Anjali Kumar',  av:'AK', role:'Senior Therapist',   spec:'Deep Tissue, Hot Stone', rating:4.9, leaves:[] },
  { id:'st2', name:'Deepa Rao',     av:'DR', role:'Wellness Therapist',  spec:'Swedish, Aromatherapy',  rating:4.8, leaves:[] },
  { id:'st3', name:'Kavya Sharma',  av:'KS', role:'Beauty Specialist',   spec:'Facials, Body Wraps',    rating:4.7, leaves:[] },
  { id:'st4', name:'Meenu Pillai',  av:'MP', role:'Therapist',           spec:'Head Spa, Reflexology',  rating:4.6, leaves:[{ date:TODAY, type:'full', reason:'Personal' }] },
];

export const INIT_DOCUMENTS: Document[] = [
  { id:'d1', name:'Shop & Establishment License', status:'verified', expiry:'Dec 2026',  type:'Legal' },
  { id:'d2', name:'GST Certificate',              status:'verified', expiry:'Perpetual', type:'Tax' },
  { id:'d3', name:'Trade License',                status:'expiring', expiry:'Apr 2026',  type:'Legal' },
  { id:'d4', name:'PAN Card',                     status:'verified', expiry:'Perpetual', type:'Tax' },
  { id:'d5', name:'Fire NOC',                     status:'pending',  expiry:'—',          type:'Safety' },
  { id:'d6', name:'FSSAI License',                status:'verified', expiry:'Aug 2026',  type:'Safety' },
  { id:'d7', name:'Hygiene Declaration',          status:'expiring', expiry:'Mar 2026',  type:'Platform' },
];

export const INIT_REVIEWS: Review[] = [
  { id:'r1', client:'Priya S.',  rating:5, text:"Absolutely divine experience. Anjali's deep tissue session was life-changing. Will definitely return.", service:'Deep Tissue Massage', date:'2 days ago' },
  { id:'r2', client:'Rohan M.',  rating:5, text:'The ambience is so calming. Swedish massage was perfect. Highly recommend.',                           service:'Swedish Massage',     date:'4 days ago' },
  { id:'r3', client:'Anika T.',  rating:4, text:'Lovely spa. The facial was rejuvenating. Could improve appointment scheduling.',                        service:'Facial + Body Wrap',  date:'1 week ago' },
  { id:'r4', client:'Vikram S.', rating:5, text:'Best couples massage! The staff was incredibly professional.',                                          service:'Aromatherapy',        date:'1 week ago' },
];

export const INIT_SETTINGS: SpaSettings = {
  spaName:'Serenity Spa & Wellness', owner:'Priya Menon',
  phone:'+91 98765 43210', email:'hello@serenityspa.in',
  city:'Mumbai, Maharashtra', open:'09:00', close:'21:00',
  desc:'Welcome to Serenity Spa. We specialise in holistic wellness and luxury beauty treatments.',
  holdDuration:300,
  notif:{ bookings:true, reviews:true, documents:false, payments:true },
};

export const INIT_AUDIT: AuditEntry[] = [
  { id:'a1', ts:'10:00 AM', action:'Booking Created',  entity:'BK001', detail:'Priya Sharma · Deep Tissue · 10:00 AM', user:'Admin' },
  { id:'a2', ts:'10:12 AM', action:'Payment Received', entity:'BK001', detail:'₹1,800 · Full payment',                 user:'Admin' },
  { id:'a3', ts:'10:28 AM', action:'Booking Created',  entity:'BK002', detail:'Rohan Mehta · Swedish · 12:00 PM',      user:'Admin' },
];

export const NAV_ITEMS = [
  { id:'overview'  as const, ic:'◈', label:'Overview' },
  { id:'bookings'  as const, ic:'◷', label:'Bookings' },
  { id:'services'  as const, ic:'✦', label:'Services & Slots' },
  { id:'customers' as const, ic:'◎', label:'Customers' },
  { id:'staff'     as const, ic:'◉', label:'Staff' },
  { id:'analytics' as const, ic:'◇', label:'Analytics' },
  { id:'waitlist'  as const, ic:'⊕', label:'Waitlist' },
  { id:'documents' as const, ic:'▣', label:'Documents' },
  { id:'reviews'   as const, ic:'◇', label:'Reviews' },
  { id:'settings'  as const, ic:'⊙', label:'Settings' },
  { id:'audit'     as const, ic:'≡', label:'Audit Log' },
];
