export type BookingStatus = 'confirmed' | 'in-progress' | 'pending' | 'cancelled';
export type PaymentStatus = 'paid' | 'partial' | 'unpaid' | 'refunded';
export type DocStatus     = 'verified' | 'expiring' | 'pending';
export type LeaveType     = 'full' | 'morning' | 'afternoon';
export type NotifType     = 'booking' | 'waitlist' | 'payment' | 'warning' | 'document';
export type ModalType     = 'newBooking' | 'customer' | 'bookingDetail' | null;

export interface Leave { date: string; type: LeaveType; reason: string; }
export interface SlotData { time: string; cap: number; conf: number; holds: number; wl: string[]; }

export interface Service {
  id: string; name: string; cat: string; dur: string;
  price: number; active: boolean; slots: SlotData[];
}
export interface Customer {
  id: string; name: string; phone: string; email: string;
  dob: string; pref: string; allergy: string; visits: number; spend: number; guest: boolean;
}
export interface Booking {
  id: string; cid: string; name: string; svcId: string; svc: string;
  th: string; thId: string; time: string; date: string;
  status: BookingStatus; pay: PaymentStatus; amt: number;
}
export interface StaffMember {
  id: string; name: string; av: string; role: string;
  spec: string; rating: number; leaves: Leave[];
}
export interface Document { id: string; name: string; status: DocStatus; expiry: string; type: string; }
export interface Review { id: string; client: string; rating: number; text: string; service: string; date: string; }
export interface NotifPrefs { bookings: boolean; reviews: boolean; documents: boolean; payments: boolean; }
export interface SpaSettings {
  spaName: string; owner: string; phone: string; email: string;
  city: string; open: string; close: string; desc: string;
  holdDuration: number; notif: NotifPrefs;
}
export interface Notification { id: string; type: NotifType; msg: string; time: string; read: boolean; }
export interface AuditEntry { id: string; ts: string; action: string; entity: string; detail: string; user: string; }

export type NavId = 'overview'|'bookings'|'services'|'customers'|'staff'|'analytics'|'waitlist'|'documents'|'reviews'|'settings'|'audit';
export interface NavItem { id: NavId; ic: string; label: string; }
