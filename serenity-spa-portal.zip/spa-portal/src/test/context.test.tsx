import { describe, it, expect } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { AppProvider, useApp } from '@/context/AppContext'
import { INIT_BOOKINGS, INIT_CUSTOMERS, TODAY } from '@/data/seed'

// Helper component to expose context values
function TestHarness({ action }: { action: () => void }) {
  const { state } = useApp()
  return (
    <div>
      <button onClick={action}>trigger</button>
      <span data-testid="booking-count">{state.bookings.length}</span>
      <span data-testid="notif-count">{state.notifs.length}</span>
    </div>
  )
}

describe('AppContext — cancelBooking', () => {
  it('marks booking as cancelled', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /><div /></AppProvider>)
    const bk = ctx!.state.bookings[0]
    expect(bk.status).not.toBe('cancelled')
    ctx!.cancelBooking(bk.id)
    const updated = ctx!.state.bookings.find(b => b.id === bk.id)
    expect(updated?.status).toBe('cancelled')
  })

  it('adds a notification on cancel', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /></AppProvider>)
    const before = ctx!.state.notifs.length
    ctx!.cancelBooking(ctx!.state.bookings[0].id)
    expect(ctx!.state.notifs.length).toBe(before + 1)
  })
})

describe('AppContext — markPaid', () => {
  it('sets payment to paid', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /></AppProvider>)
    const unpaid = ctx!.state.bookings.find(b => b.pay === 'unpaid')
    expect(unpaid).toBeDefined()
    ctx!.markPaid(unpaid!.id)
    const updated = ctx!.state.bookings.find(b => b.id === unpaid!.id)
    expect(updated?.pay).toBe('paid')
  })
})

describe('AppContext — markAllRead', () => {
  it('marks all notifications as read', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /></AppProvider>)
    ctx!.addNotif('booking', 'Test notification')
    ctx!.markAllRead()
    expect(ctx!.state.notifs.every(n => n.read)).toBe(true)
  })
})

describe('AppContext — navigation', () => {
  it('updates nav state', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /></AppProvider>)
    expect(ctx!.state.nav).toBe('overview')
    ctx!.setNav('bookings')
    expect(ctx!.state.nav).toBe('bookings')
  })
})

describe('AppContext — sidebar', () => {
  it('toggles sidebar', () => {
    let ctx: ReturnType<typeof useApp>
    function Grabber() { ctx = useApp(); return null }
    render(<AppProvider><Grabber /></AppProvider>)
    const initial = ctx!.state.sidebar
    ctx!.toggleSidebar()
    expect(ctx!.state.sidebar).toBe(!initial)
  })
})
