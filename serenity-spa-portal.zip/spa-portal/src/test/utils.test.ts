import { describe, it, expect } from 'vitest'
import { fmtINR, initials, avColor, avColors, ST_CONFIG, PAY_CONFIG } from '@/utils'

describe('fmtINR', () => {
  it('formats zero', ()        => expect(fmtINR(0)).toBe('₹0'))
  it('formats thousands',  ()  => expect(fmtINR(1800)).toContain('1,800'))
  it('formats lakhs',      ()  => expect(fmtINR(24600)).toContain('24,600'))
})

describe('initials', () => {
  it('extracts two-word initials', () => expect(initials('Priya Sharma')).toBe('PS'))
  it('extracts first two chars',   () => expect(initials('Rohan Mehta')).toBe('RM'))
  it('handles single word',        () => expect(initials('Admin')).toBe('AD'))
})

describe('avColor', () => {
  it('cycles through palette',  () => expect(avColor(0)).toBe(avColors[0]))
  it('wraps around correctly',  () => expect(avColor(avColors.length)).toBe(avColors[0]))
  it('returns valid colour string', () => expect(avColor(1)).toMatch(/^#[0-9A-Fa-f]{6}$/))
})

describe('ST_CONFIG', () => {
  it('has confirmed config',    () => expect(ST_CONFIG.confirmed).toBeDefined())
  it('has in-progress config',  () => expect(ST_CONFIG['in-progress']).toBeDefined())
  it('has cancelled config',    () => expect(ST_CONFIG.cancelled).toBeDefined())
  it('each entry has 3 values', () => {
    Object.values(ST_CONFIG).forEach(cfg => expect(cfg).toHaveLength(3))
  })
})

describe('PAY_CONFIG', () => {
  it('has paid config',    () => expect(PAY_CONFIG.paid).toBeDefined())
  it('has unpaid config',  () => expect(PAY_CONFIG.unpaid).toBeDefined())
  it('has partial config', () => expect(PAY_CONFIG.partial).toBeDefined())
  it('each entry has 3 values', () => {
    Object.values(PAY_CONFIG).forEach(cfg => expect(cfg).toHaveLength(3))
  })
})
