import { createContext, useContext, useReducer, useCallback, type ReactNode } from 'react';
import type { Customer, Service, Booking, StaffMember, Document, Review, SpaSettings, Notification, AuditEntry, Leave, NotifType } from '../types';
import { INIT_CUSTOMERS, INIT_SERVICES, INIT_BOOKINGS, INIT_STAFF, INIT_DOCUMENTS, INIT_REVIEWS, INIT_SETTINGS, INIT_AUDIT, TODAY } from '../data/seed';
import { tNow, fmtINR } from '../utils';

interface State {
  customers:     Customer[];
  services:      Service[];
  bookings:      Booking[];
  staff:         StaffMember[];
  documents:     Document[];
  reviews:       Review[];
  settings:      SpaSettings;
  notifications: Notification[];
  audit:         AuditEntry[];
}

type Action =
  | { type: 'ADD_BOOKING';    payload: Booking }
  | { type: 'CANCEL_BOOKING'; id: string }
  | { type: 'MARK_PAID';      id: string }
  | { type: 'REMOVE_WL';      svcId: string; time: string; custId: string }
  | { type: 'ADD_LEAVE';      staffId: string; leave: Leave }
  | { type: 'ADD_NOTIF';      notif: Notification }
  | { type: 'MARK_ALL_READ' }
  | { type: 'ADD_AUDIT';      entry: AuditEntry };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'ADD_BOOKING': {
      const { payload: bk } = action;
      return {
        ...state,
        bookings: [...state.bookings, bk],
        services: state.services.map(s =>
          s.id !== bk.svcId ? s : {
            ...s,
            slots: s.slots.map(sl =>
              sl.time !== bk.time ? sl : { ...sl, conf: sl.conf + 1 }
            ),
          }
        ),
        customers: state.customers.map(c =>
          c.id !== bk.cid ? c : { ...c, visits: c.visits + 1, spend: c.spend + bk.amt }
        ),
      };
    }
    case 'CANCEL_BOOKING': {
      const bk = state.bookings.find(b => b.id === action.id);
      if (!bk || bk.status === 'cancelled') return state;
      return {
        ...state,
        bookings: state.bookings.map(b =>
          b.id !== action.id ? b : { ...b, status: 'cancelled' }
        ),
        services: state.services.map(s =>
          s.id !== bk.svcId ? s : {
            ...s,
            slots: s.slots.map(sl =>
              sl.time !== bk.time ? sl : { ...sl, conf: Math.max(0, sl.conf - 1) }
            ),
          }
        ),
      };
    }
    case 'MARK_PAID':
      return { ...state, bookings: state.bookings.map(b => b.id !== action.id ? b : { ...b, pay: 'paid' }) };
    case 'REMOVE_WL':
      return {
        ...state,
        services: state.services.map(s =>
          s.id !== action.svcId ? s : {
            ...s,
            slots: s.slots.map(sl =>
              sl.time !== action.time ? sl : { ...sl, wl: sl.wl.filter(id => id !== action.custId) }
            ),
          }
        ),
      };
    case 'ADD_LEAVE':
      return { ...state, staff: state.staff.map(s => s.id !== action.staffId ? s : { ...s, leaves: [...s.leaves, action.leave] }) };
    case 'ADD_NOTIF':
      return { ...state, notifications: [action.notif, ...state.notifications].slice(0, 50) };
    case 'MARK_ALL_READ':
      return { ...state, notifications: state.notifications.map(n => ({ ...n, read: true })) };
    case 'ADD_AUDIT':
      return { ...state, audit: [action.entry, ...state.audit].slice(0, 200) };
    default:
      return state;
  }
}

const initialState: State = {
  customers: INIT_CUSTOMERS, services: INIT_SERVICES, bookings: INIT_BOOKINGS,
  staff: INIT_STAFF, documents: INIT_DOCUMENTS, reviews: INIT_REVIEWS,
  settings: INIT_SETTINGS, notifications: [], audit: INIT_AUDIT,
};

interface ContextValue extends State {
  confirmBooking:  (svcId: string, time: string, thId: string, custId: string) => boolean;
  cancelBooking:   (id: string) => void;
  markPaid:        (id: string) => void;
  removeWaitlist:  (svcId: string, time: string, custId: string) => void;
  addStaffLeave:   (staffId: string, leave: Leave) => void;
  markAllRead:     () => void;
  addNotification: (type: NotifType, msg: string) => void;
}

const AppContext = createContext<ContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const addAudit = useCallback((action: string, entity: string, detail: string) => {
    dispatch({ type: 'ADD_AUDIT', entry: { id: 'a' + Date.now(), ts: tNow(), action, entity, detail, user: 'Admin' } });
  }, []);

  const addNotification = useCallback((type: NotifType, msg: string) => {
    dispatch({ type: 'ADD_NOTIF', notif: { id: 'n' + Date.now(), type, msg, time: tNow(), read: false } });
  }, []);

  const confirmBooking = useCallback((svcId: string, time: string, thId: string, custId: string): boolean => {
    const svc  = state.services.find(s => s.id === svcId);
    const cust = state.customers.find(c => c.id === custId);
    const th   = state.staff.find(s => s.id === thId);
    const slot = svc?.slots.find(sl => sl.time === time);
    if (!svc || !cust || !th || !slot) return false;
    if (slot.conf + slot.holds >= slot.cap) return false;
    const id = 'BK' + String(state.bookings.length + 100).padStart(3, '0');
    const thLabel = th.name.split(' ')[0] + ' ' + th.name.split(' ')[1][0] + '.';
    dispatch({ type: 'ADD_BOOKING', payload: { id, cid: custId, name: cust.name, svcId, svc: svc.name, th: thLabel, thId, time, date: TODAY, status: 'confirmed', pay: 'unpaid', amt: svc.price } });
    addAudit('Booking Created', id, `${cust.name} · ${svc.name} · ${time}`);
    addNotification('booking', `Booking confirmed: ${cust.name} · ${svc.name} · ${time}`);
    return true;
  }, [state.services, state.customers, state.staff, state.bookings.length, addAudit, addNotification]);

  const cancelBooking = useCallback((id: string) => {
    const bk = state.bookings.find(b => b.id === id);
    if (!bk) return;
    dispatch({ type: 'CANCEL_BOOKING', id });
    addAudit('Booking Cancelled', id, `${bk.name} · ${bk.svc} · ${bk.time}`);
    addNotification('booking', `Booking ${id} cancelled: ${bk.name}`);
  }, [state.bookings, addAudit, addNotification]);

  const markPaid = useCallback((id: string) => {
    const bk = state.bookings.find(b => b.id === id);
    dispatch({ type: 'MARK_PAID', id });
    addAudit('Payment Received', id, `${bk?.name} · ${fmtINR(bk?.amt ?? 0)}`);
    addNotification('payment', `Payment received: ${bk?.name} · ${fmtINR(bk?.amt ?? 0)}`);
  }, [state.bookings, addAudit, addNotification]);

  const removeWaitlist = useCallback((svcId: string, time: string, custId: string) => {
    dispatch({ type: 'REMOVE_WL', svcId, time, custId });
    addAudit('Waitlist Removed', `${svcId}·${time}`, 'Customer removed');
  }, [addAudit]);

  const addStaffLeave = useCallback((staffId: string, leave: Leave) => {
    dispatch({ type: 'ADD_LEAVE', staffId, leave });
    const st = state.staff.find(s => s.id === staffId);
    addAudit('Leave Added', staffId, `${st?.name} · ${leave.date} · ${leave.type}`);
  }, [state.staff, addAudit]);

  const markAllRead = useCallback(() => dispatch({ type: 'MARK_ALL_READ' }), []);

  return (
    <AppContext.Provider value={{ ...state, confirmBooking, cancelBooking, markPaid, removeWaitlist, addStaffLeave, markAllRead, addNotification }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): ContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
