/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream:  '#FAF4EE',
        linen:  '#F2DDD5',
        rose:   '#C9897A',
        gold:   '#D4AF7A',
        terra:  '#A4594A',
        dark:   '#2E1A1A',
        mauve:  '#7A4A4A',
        muted:  '#B09080',
        'border-soft': 'rgba(201,137,122,0.15)',
        'border-mid':  'rgba(201,137,122,0.25)',
        'spa-green':  '#5a9a5a',
        'spa-amber':  '#b8860b',
        'spa-red':    '#c05050',
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        editorial: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Jost', 'system-ui', 'sans-serif'],
      },
      animation: {
        'slide-in': 'slideIn 0.2s ease',
      },
      keyframes: {
        slideIn: {
          from: { transform: 'translateY(12px)', opacity: '0' },
          to:   { transform: 'translateY(0)',    opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
